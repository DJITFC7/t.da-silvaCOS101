use std::io;

fn main() {
   
   println!("Enter customer name");
   let mut name = String::new();
   io::stdin().read_line(&mut name).expect("Not a valid input");
  

   println!("Enter units consumed");
   let mut unit_input = String::new();
   io::stdin().read_line(&mut unit_input).expect("not a valid input");
   let unit:f64 = unit_input.trim().parse().expect("not a valid number");

  if unit_input  >= 0.0. && unit_input <= 100.0 {
    total_cost == unit_input * 20.0;
    println!("total cost is {}", total_cost );
  }else if unit_input > 100.0 && unit_input <= 300.0 {
      total_cost == unit_input * 35.0;
      println!("total cost is {}", total_cost );
  }else if unit_input > 300.0 {
    total_cost == unit_input * 50.0;
    println!("total cost is {}", total_cost );
  }else if unit_input > 500.0 {
    total_cost == unit_input + 5_000.0;
    println!("total cost is {}", total_cost );
  }

   }